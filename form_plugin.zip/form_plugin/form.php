<?php
/* plugin name: Form Plugin*/
/*Description: Task plugin*/
/* version: 1.0*/
/*Author: Hassan khan */
?>
<?php
function website_form(){
if(!empty($_POST)) {

unset($args_team);


$args_team = array(
'post_title' => stripslashes($_POST['u_name']),
'post_content' => stripslashes($_POST['team_description']),
'post_type' => 'websites',
'post_status' => 'pending',
);

$pid = wp_insert_post($args_team);

update_post_meta($pid, "email_address", stripslashes($_POST['ur_website']));	
wp_set_object_terms( $pid, $_POST['ur_website'], 'ur_website' );





}
?>
<style>
#add_team label {
	display: block;
	margin: 10px 0 10px 0;
}

#add_team field
{
	
}
#add_team input[type="text"], #add_team textarea,#add_team select {
	width: 100%;
}
#add_team {
	width: 400px;
}

#add_team label {
	display: block;
	margin: 10px 0 10px 0;
	font-size: 14px;
	font-weight: bold;
}
</style>
	<div id="primary" class="site-content">
		<div id="content" role="main">
<form class="rs_form" name="add-team-form" id="add_team" enctype="multipart/form-data" method="post" action="
<?php get_permalink( get_the_ID() );?>">
<div class="field">
<label>Name</label>
<input type="text" class="fom abc" id="u_name" name="u_name"  required /></div>

<div class="field">
<label>Website URL</label>
<input type="URL" class="fom abc" id="ur_website" name="ur_website"  required /></div>


<br />
<br />

<div class="field"><input type="submit" name="submit" value="add Detials" /></div>
</form>

		</div><!-- #content -->
	</div><!-- #primary -->

<?php
}

add_shortcode("form",'website_form')
?>

<?php




// Our custom post type function

function custom_post_type() {
  

    $labels = array(
        'name'                => _x( 'WEBSITES', 'Post Type General Name', 'twentytwentyone' ),
        'singular_name'       => _x( 'WEBSITE', 'Post Type Singular Name', 'twentytwentyone' ),
        'menu_name'           => __( 'WEBSITES', 'twentytwentyone' ),
        'parent_item_colon'   => __( 'Parent websites', 'twentytwentyone' ),
        'all_items'           => __( 'All websites', 'twentytwentyone' ),
        'view_item'           => __( 'View websites', 'twentytwentyone' ),
        'add_new_item'        => __( 'Add New websites', 'twentytwentyone' ),
        'add_new'             => __( 'Add New', 'twentytwentyone' ),
        'edit_item'           => __( 'Edit websites', 'twentytwentyone' ),
        'update_item'         => __( 'Update websites', 'twentytwentyone' ),
        'search_items'        => __( 'Search websites', 'twentytwentyone' ),
        'not_found'           => __( 'Not Found', 'twentytwentyone' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentytwentyone' ),
    );
      
      
    $args = array(
        'label'               => __( 'webstes', 'websites' ),
        'description'         => __( 'websites' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
      
        'taxonomies'          => array( 'genres' ),
       
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
        'show_in_rest' => true,


  'capability_type' => 'post',
					 'capabilities' => array( // allow only to admin
						'publish_posts' => 'manage_options',
						'edit_posts' => 'manage_options',
						'edit_others_posts' => 'manage_options',
						'delete_posts' => 'manage_options',
						'delete_others_posts' => 'manage_options',
						'read_private_posts' => 'manage_options',
						'edit_post' => 'manage_options',
						'delete_post' => 'manage_options',
						'read_post' => 'manage_options',
					),


    );

      
    // Registering your Custom Post Type
    register_post_type( 'websites', $args );
  
}
  
add_action( 'init', 'custom_post_type', 0 );

add_action('admin_init', 'website_meta');

function website_meta() {
    add_meta_box('website',
        __('website', 'textdomain'),
        'my_metabox_render',
        'websites', 'normal', 'high'
    );
}
add_action( 'add_meta_boxes', 'remove_metaboxes', 5 ); 
function remove_metaboxes(){
    global $wp_meta_boxes;
    global $post;
    $current_post_type = get_post_type($post);
    if($current_post_type == 'websites') {
        $publishbox = $wp_meta_boxes['websites']['side']['core']['submitdiv'];
        $wp_meta_boxes = array();
        $wp_meta_boxes['websites'] = array(
            'side' => array('core' => array('submitdiv' => $publishbox))
          );
    }
}


